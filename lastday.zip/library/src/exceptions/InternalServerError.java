package exceptions;

public class InternalServerError extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2447769675789110933L;

	public InternalServerError(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	

}
