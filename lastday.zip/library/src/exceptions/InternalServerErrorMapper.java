package exceptions;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import model.ErrorMessage;

//@Provider
public class InternalServerErrorMapper implements ExceptionMapper<Throwable> {

	@Override
	public Response toResponse(Throwable e) {
		
		ErrorMessage modelError = new ErrorMessage(e.getMessage(),500,"http://helplink.help.org");
// TODO Auto-generated method stub
		return Response.status(Status.NOT_FOUND).entity(modelError).build();
	}



}
