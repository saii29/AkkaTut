package model;

import java.util.List;

import javax.xml.bind.annotation.XmlTransient;


public class Book {
	
	private int isbn;
	private String title;
	private String language;
	private int pages;
	private String status;
	private List<Author> author;
	private List<Review> review;
	
	
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book(int isbn, String title, String language, int pages, String status, List<Author> author,
			List<Review> review) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.language = language;
		this.pages = pages;
		this.status = status;
		this.author = author;
		this.review = review;
	}
	
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<Author> getAuthor() {
		return author;
	}
	public void setAuthor(List<Author> author) {
		this.author = author;
	}

//	@XmlTransient
	public List<Review> getReview() {
		return review;
	}
	public void setReview(List<Review> review) {
		this.review = review;
	}
	
	
	
		
}
