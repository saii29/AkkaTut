package service;

import java.util.ArrayList;
import java.util.List;

import dao.ReviewDAO;
import dao.ReviewDAOImpl;
import model.Book;
import model.Review;

public class ReviewServiceImpl implements ReviewService {

	private ReviewDAO dao = new ReviewDAOImpl();

	@Override
	public List<Review> getAllReviews(int bookId) {
		// TODO Auto-generated method stub
		return dao.getAllReviews(bookId);
	}

	@Override
	public Review addReview(int bookId, Review review) {
		// TODO Auto-generated method stub
		return dao.addReview(bookId, review);
	}

}
