package service;

import java.util.List;

import dao.BookDAO;
import dao.BookDAOImpl;
import model.Author;
import model.Book;

public class BookServiceImpl implements BookService {
BookDAO dao = new BookDAOImpl();

@Override
public Book addBook(Book book) {
	// TODO Auto-generated method stub
	return dao.addBook(book);
}

@Override
public List<Book> getBooks() {
	// TODO Auto-generated method stub
	return dao.getBooks();
}


@Override
public List<Book> getQueryBooks(String status) {
	// TODO Auto-generated method stub
	return dao.getQueryBooks(status);
}

@Override
public Book updateBook(int id, Book book) {
	// TODO Auto-generated method stub
	return dao.updateBook(id,book);
}

@Override
public Book updateAuthor(int id, int authorId, Author author) {
	// TODO Auto-generated method stub
	return dao.updateAuthor(id,authorId, author);
}

}
