package service;

import java.util.ArrayList;
import java.util.List;

import model.Book;
import model.Review;

public interface ReviewService {

	List<Review> getAllReviews(int bookId);

	Review addReview(int bookId, Review review);
	
	
	

}
