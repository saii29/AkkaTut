package dao;

import java.util.List;

import model.Author;
import model.Book;

public interface BookDAO {

	public Book addBook(Book book);

	public List<Book> getBooks();

	public List<Book> getQueryBooks(String status);

	public Book updateBook(int id, Book book);

	public Book updateAuthor(int id, int authorId, Author author);

}
