package dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Author;
import model.Book;

public class BookDAOImpl implements BookDAO{


	public static Map<Integer,Book> library = new HashMap<Integer,Book>();


	@Override
	public Book addBook(Book book) {
		// TODO Auto-generated method stub
//		library.keySet().toArray();
		if(library.keySet().isEmpty())
		{
			book.setIsbn(1);
		}
		else
		{
			System.out.println(Collections.max(library.keySet()));
			book.setIsbn((Collections.max(library.keySet())+1));
		}
		
		int count = 1;
		for(Author x:book.getAuthor())
		{
			x.setId(count);
			count++;
		}
		if(book.getStatus()==null)
		{
			book.setStatus("available");
		}

		library.put(book.getIsbn(),book);
		return book;
	}

	@Override
	public List<Book> getBooks() {
		// TODO Auto-generated method stub
		return new ArrayList<Book>(library.values());
	}

	@Override
	public List<Book> getQueryBooks(String status) {
		// TODO Auto-generated method stub
		ArrayList<Book> al = new ArrayList<Book>(library.values());
		ArrayList<Book> rl = new ArrayList<Book>();
		for(Book m:al){
			if(m.getStatus().equalsIgnoreCase(status)){
				rl.add(m);
			}
		
		}
		return rl;
	}

	@Override
	public Book updateBook(int id, Book book) {
		// TODO Auto-generated method stub
		if(book.getStatus()!=null)
		{
			library.get(id).setStatus(book.getStatus());
		}
		return library.get(id);
	}

	@Override
	public Book updateAuthor(int id, int authorId, Author author) {
		// TODO Auto-generated method stub
//		if(library.get(id).getAuthor().contains(author))
//		{
//			library.get(id).setAuthor(author);
//		}
		return null;
	}
	
	
	

}
