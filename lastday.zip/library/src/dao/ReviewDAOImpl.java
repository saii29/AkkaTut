package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import model.Book;
import model.Review;

public class ReviewDAOImpl implements ReviewDAO {

//	BookDAO bo = new BookDAOImpl();
	
	@Override
	public List<Review> getAllReviews(int bookId) {
		// TODO Auto-generated method stub
		return BookDAOImpl.library.get(bookId).getReview();
	}

	@Override
	public Review addReview(int bookId, Review review) {
		// TODO Auto-generated method stub
		
		BookDAOImpl.library.get(bookId).setReview((List<Review>) review);
		
		return review;
	}
	

	
}
