package dao;

import java.util.ArrayList;
import java.util.List;

import model.Book;
import model.Review;

public interface ReviewDAO {

	List<Review> getAllReviews(int bookId);

	Review addReview(int bookId, Review review);

}
