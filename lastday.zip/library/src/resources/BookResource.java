package resources;

import java.net.URI;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import exceptions.DataNotFoundException;
import model.ErrorMessage;
import model.Author;
import model.Book;
import service.BookService;
import service.BookServiceImpl;

@Path("/books")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BookResource {

	BookService service = new BookServiceImpl();
	

	@GET
	@Path("/query")
	public List<Book> getQueryBooks(@QueryParam("status") String status)
	{
		return service.getQueryBooks(status);
	}

	@GET
	public List<Book> getBooks()
	{
		return service.getBooks();
	}

	
	@POST
	public Response addBook(Book book, @Context UriInfo uriInfo)
	{
		Book newBook = service.addBook(book);
//		Response resp = Response.status(Status.CREATED).entity(msg).build();
		Response.status(Status.CREATED).entity(newBook).build();
		String newBookId = String.valueOf(newBook.getIsbn());
		URI uri = uriInfo.getAbsolutePathBuilder().path(newBookId).build();
		
//		return resp;
		return Response.created(uri).entity(newBook).build();
	}	
	
	
	@PUT
	@Path("/{bookId}")
	public Book updateBook(@PathParam("bookId") int id, Book book)
	{
		return service.updateBook(id, book);
	}
	
	@PUT
	@Path("/{bookId}/{authorId}")
	public Book updateAuthor(@PathParam("bookId") int id,@PathParam("authorId") int authorId, Author author)
	{
		return service.updateAuthor(id, authorId, author);
	}

	@Path("/{bookId}/reviews")
	public ReviewResource comments()
	{
		return new ReviewResource();
	}
	


}
