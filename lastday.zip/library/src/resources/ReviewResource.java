package resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import model.Review;
import service.ReviewService;
import service.ReviewServiceImpl;


@Path("/")
public class ReviewResource {
	private ReviewService reviewService = new ReviewServiceImpl();

	@GET
	public List<Review> getAllReviews(@PathParam("bookId") int bookId )
	{
		
		return reviewService.getAllReviews(bookId);
	}
	
	@POST
	public Review addReview(@PathParam("bookId") int bookId, Review review)
	{
		return reviewService.addReview(bookId, review);
		
	}
}
