package resources;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

@Path("/contextDemo")
public class ContextDemoResource {

	@GET
	@Path("/context")
	@Produces(MediaType.TEXT_PLAIN)
	public String getDataUsingContext(@Context UriInfo uriInfo,@Context HttpHeaders headers)
	{
		String path = uriInfo.getAbsolutePath().toString();
		String baseUri = uriInfo.getBaseUri().getPath();
//		String mediaTypes = headers.getMediaType().getType(); 
		
		
		return "Path : "+path+" base uri "+baseUri+" media type ";
	}
	
}
