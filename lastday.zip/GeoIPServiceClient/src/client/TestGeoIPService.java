package client;

import net.webservicex.GeoIP;
import net.webservicex.GeoIPService;
import net.webservicex.GeoIPServiceSoap;

public class TestGeoIPService {
	
	
	public static void main(String[] args) {
		GeoIPService service =new GeoIPService();
		GeoIPServiceSoap obj = service.getGeoIPServiceSoap();
		GeoIP geoIP = obj.getGeoIP("151.101.100.81");
		System.out.println("The country name is " + geoIP.getCountryName());
		
		
	}

}
