package resources;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import exceptions.InsufficientBalanceException;
import exceptions.InvalidAccountException;
import model.Account;
import model.Transfer;
import service.AccountService;
import service.AccountServiceImpl;

@WebService
public class AccountResource {
	
	AccountService service = new AccountServiceImpl();
	
	@WebMethod
	@WebResult(name="ListOfAccounts")
	public List<Account> getAccounts()
	{
		return service.getAccountList();
	}

	@WebMethod
	@WebResult(name="AddedAccount")
	public Account addAccount(@WebParam(name="EnterAccountDetails") Account account)
	{
		return service.addAccount(account);
	}
	
	@WebMethod
	@WebResult(name="TransferStatus")
	public List<Account> transferMoney(@WebParam(name="EnterDetails") Transfer transfer) throws InvalidAccountException
	{
		
		
		return service.transferMoney(transfer);
		
	}
	
	@WebMethod
	@WebResult(name="WithdrawStatus")
	public Account withdrawMoney(@WebParam(name="EnterDetails") Account account) throws InsufficientBalanceException, InvalidAccountException
	{
		return service.withdrawMoney(account);
		
	}

	@WebMethod
	@WebResult(name="DepositStatus")
	public Account depositMoney(@WebParam(name="EnterDetails") Account account) throws InvalidAccountException
	{
		return service.depositMoney(account);
		
	}
}
