package service;

import java.util.List;

import exceptions.InsufficientBalanceException;
import exceptions.InvalidAccountException;
import model.Account;
import model.Transfer;

public interface AccountService {
	
	public List<Account> getAccountList();

	public Account addAccount(Account account);

	public Account withdrawMoney(Account account) throws InsufficientBalanceException, InvalidAccountException;

	public List<Account> transferMoney(Transfer transfer) throws InvalidAccountException;

	public Account depositMoney(Account account) throws InvalidAccountException;

	

}
