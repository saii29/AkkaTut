package service;

import java.util.List;

import dao.AccountDAO;
import dao.AccountDAOImpl;
import exceptions.InsufficientBalanceException;
import exceptions.InvalidAccountException;
import model.Account;
import model.Transfer;

public class AccountServiceImpl implements AccountService {

	AccountDAO dao = new AccountDAOImpl();

	@Override
	public List<Account> getAccountList() {
		// TODO Auto-generated method stub
		return dao.getAccountList();
	}

	@Override
	public Account addAccount(Account account) {
		// TODO Auto-generated method stub
		return dao.addAccount(account);
	}

	@Override
	public Account withdrawMoney(Account account) throws InsufficientBalanceException, InvalidAccountException {
		// TODO Auto-generated method stub
		return dao.withdrawMoney(account);
	}

	@Override
	public List<Account> transferMoney(Transfer transfer) throws InvalidAccountException {
		// TODO Auto-generated method stub
		return dao.transferMoney(transfer);
	}

	@Override
	public Account depositMoney(Account account) throws InvalidAccountException {
		// TODO Auto-generated method stub
		return dao.depositMoney(account);
	}



}
