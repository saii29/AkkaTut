package exceptions;

public class InsufficientBalanceException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2592583677638132357L;
	private String errorDetails;
	
	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	public InsufficientBalanceException(String reason, String errorDetails){
		super(reason);
		this.errorDetails = errorDetails;
	}

}
