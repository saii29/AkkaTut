package exceptions;

public class InvalidAccountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1167823606916005037L;
	private String errorDetails;
	
	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	public InvalidAccountException(String reason, String errorDetails){
		super(reason);
		this.errorDetails = errorDetails;
	}

}
