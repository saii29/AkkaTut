package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import exceptions.InsufficientBalanceException;
import exceptions.InvalidAccountException;
import model.Account;
import model.Transfer;

public class AccountDAOImpl implements AccountDAO {

	public AccountDAOImpl() {
		for(int i=1;i<6;i++){
			Account account = new Account();
			account.setId(i);
			account.setName("a"+i);
			account.setAmount(1000*i);
			accounts.put(i, account);
		}
	}

	public static Map<Integer,Account> accounts = new HashMap<Integer,Account>();
	



	@Override
	public List<Account> getAccountList() {
		// TODO Auto-generated method stub
		
		return new ArrayList<Account>(accounts.values());
	}

	@Override
	public Account addAccount(Account account) {
		// TODO Auto-generated method stub
		accounts.put(account.getId(),account);
		
		return account;
	}

	@Override
	public Account withdrawMoney(Account account) throws InsufficientBalanceException, InvalidAccountException {
		// TODO Auto-generated method stub

		if(!accounts.containsKey(account.getId()))
			throw new InvalidAccountException("Invalid Account", "Account doesn't exist");

		float remainigBal = accounts.get(account.getId()).getAmount() - account.getAmount();
		if(remainigBal <1000)
			throw new InsufficientBalanceException("Insufficient Balance", "Your account balance is low");
		else {
			account.setAmount(remainigBal);
			account.setName(accounts.get(account.getId()).getName());
			accounts.replace(account.getId(), account);
		}
		
		return account;
	}

	@Override
	public List<Account> transferMoney(Transfer transfer) throws InvalidAccountException {
		// TODO Auto-generated method stubsd
		if(!accounts.containsKey(transfer.getFromAccount()))
			throw new InvalidAccountException("Invalid Account", "From Account doesn't exist");

		if(!accounts.containsKey(transfer.getToAccount()))
			throw new InvalidAccountException("Invalid Account", "To Account doesn't exist");

		float updateFromBal = accounts.get(transfer.getFromAccount()).getAmount() - transfer.getAmount();
		float updateToBal = accounts.get(transfer.getToAccount()).getAmount() + transfer.getAmount();
		ArrayList<Account> transferAccounts = new ArrayList<Account>();
		accounts.get(transfer.getFromAccount()).setAmount(updateFromBal);
		accounts.get(transfer.getToAccount()).setAmount(updateToBal);
		transferAccounts.add(accounts.get(transfer.getFromAccount()));
//		transferAccounts.add(accounts.get(transfer.getToAccount()));
		
		return transferAccounts;
	}

	@Override
	public Account depositMoney(Account account) throws InvalidAccountException {
		// TODO Auto-generated method stub
		if(!accounts.containsKey(account.getId()))
			throw new InvalidAccountException("Invalid Account", "Account doesn't exist");
		
		float updateBal = accounts.get(account.getId()).getAmount() + account.getAmount();
		accounts.get(account.getId()).setAmount(updateBal);

		return  accounts.get(account.getId());
	}

}
