package services;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import exceptions.InvalidNameException;

import model.Person;


@WebService
public class Hello {
	
	@WebMethod(exclude=true)
	public String sayHello(){
		return "Hello Webservice";
	}

	@WebMethod
	@WebResult(name="greetingResult")
	public String sayHelloAgain(@WebParam(name="name") String name) throws InvalidNameException{
	
		if("invalid".equals(name))
		{
			throw new InvalidNameException("InvalidName", "name cannot be invalid");
		}
		return "Hello again "+ name;
	}
	
	public Person sayHelloToPerson(Person person){
		Person p =new Person();
		p.setName("Hello " + person.getName());
		return p;
	}
	

}
