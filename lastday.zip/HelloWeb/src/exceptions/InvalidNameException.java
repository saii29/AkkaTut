package exceptions;

public class InvalidNameException extends Exception {

	private String errorDetails;
	
	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	public InvalidNameException(String reason, String errorDetails){
		super(reason);
		this.errorDetails = errorDetails;
	}
	
	
	
}
