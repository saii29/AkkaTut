package resources;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import domain.Comment;
import service.CommentsService;
import service.CommentsServiceImpl;

@Path("/")
public class CommentResource {
	private CommentsService commentService = new CommentsServiceImpl();

	@GET
	public List<Comment> getAllComments(@PathParam("messageId") int messageId )
	{
		
		return new ArrayList<Comment>(commentService.getAllComments(messageId).values());
	}
	
	@POST
	public Comment addComment(@PathParam("messageId") int messageId, Comment comment)
	{
		return commentService.addComment(messageId, comment);
		
	}
}
