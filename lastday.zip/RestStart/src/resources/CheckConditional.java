package resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;

import domain.Message;
import service.MessageService;
import service.MessageServiceImpl;

@Path("/conditional")
public class CheckConditional {

	MessageService messageService = new MessageServiceImpl();

	@GET
	@Path("/{messageId}")
	public Response getMessage(@PathParam("messageId") int id, @Context Request req)
	{
		
		CacheControl cc = new CacheControl();
		cc.setMaxAge(86400);
		Response.ResponseBuilder rb = null;
		EntityTag eTag = new EntityTag(messageService.getMessage(id).hashCode()+"");
		//verify match
		rb = req.evaluatePreconditions(eTag);
		if(rb != null)
		{
		return rb.cacheControl(cc).tag(eTag).build();
		}
		rb = Response.ok(messageService.getMessage(id)).cacheControl(cc).tag(eTag);
//		If_None_Match  etag
		
		return rb.build();
	}
}
