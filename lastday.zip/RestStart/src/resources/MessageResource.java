package resources;

import java.net.URI;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import domain.ErrorMessage;
import domain.Message;
import exceptions.DataNotFoundException;
import service.MessageService;
import service.MessageServiceImpl;

@Path("/messages")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MessageResource {

	MessageService service = new MessageServiceImpl();
	
	@GET
	public List<Message> getMessage()
	{
		return service.getMessage();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Message> getMessage1()
	{
		return service.getMessage();
	}
	
	@GET
	@Path("/{messageId}")
	public Message getMessage(@PathParam("messageId") int id) throws Exception
	{
//		Message message = service.getMessage(id);
//		if(message==null)  throw new Exception("message not found---");
//		return message;
		
		Message message = service.getMessage(id);
		if(message==null){
		ErrorMessage modelError = new ErrorMessage("Error msgss",500,"http://helplink.help.org");
		Response response = Response.status(Status.NOT_FOUND).entity(modelError).build(); 
		throw new WebApplicationException(response);
		}
		return message;
	}
	
	@GET
	@Path("/query")
	public List<Message> getMessages(@QueryParam("author") String author)
	{
		return service.getMessages(author);
	}
	
	@POST
	public Response addMessage(Message message, @Context UriInfo uriInfo)
	{
		Message msg = service.addMessage(message);
//		Response resp = Response.status(Status.CREATED).entity(msg).build();
		Response.status(Status.CREATED).entity(msg).build();
		String newMsgId = String.valueOf(msg.getId());
		URI uri = uriInfo.getAbsolutePathBuilder().path(newMsgId).build();
		
//		return resp;
		return Response.created(uri).entity(msg).build();
	}
	
	@PUT
	@Path("/{messageId}")
	public Message updateMessage(@PathParam("messageId") int id,Message message)
	{
		return service.updateMessage(id, message);
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_XML)
	public Message updateMessage1(@PathParam("messageId") int id, Message message)
	{
		System.out.println("put method of xml	");
		return service.updateMessage(id, message);
	}

	
	@DELETE
	@Path("/{messageId}")
	public void deleteMessage(@PathParam("messageId") int id)
	{
		service.deleteMessage(id);
	}
	
	@Path("/{messageId}/comments")
	public CommentResource comments()
	{
		return new CommentResource();
	}
	

}
