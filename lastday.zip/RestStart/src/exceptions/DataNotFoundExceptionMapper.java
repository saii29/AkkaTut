package exceptions;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import domain.ErrorMessage;


@Provider
public class DataNotFoundExceptionMapper implements ExceptionMapper<DataNotFoundException>{

	@Override
	public Response toResponse(DataNotFoundException e) {
		
		ErrorMessage modelError = new ErrorMessage(e.getMessage(),404,"http://helplink.help.org");
		// TODO Auto-generated method stub
		return Response.status(Status.NOT_FOUND).entity(modelError).build();
	}

	
	
}
