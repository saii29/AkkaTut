package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import domain.Message;

public class MessageDAOImpl implements MessageDAO{

	public static Map<Integer,Message> messages = new HashMap<Integer,Message>();

	@Override
	public List<Message> getMessage() {

		return new ArrayList<Message>(messages.values());
	}

	@Override
	public Message addMessage(Message message) {
		message.setId((messages.size()+1));
		messages.put(message.getId(),message);
		return message;
	}

	@Override
	public Message updateMessage(int id, Message message) {
		messages.replace(id, message);		
		return message;
	}

	@Override
	public void deleteMessage(int id) {
		messages.remove(id);
	}

	@Override
	public Message getMessage(int id) {
		return 	messages.get(id);		

	}

	@Override
	public List<Message> getMessages(String author) {
		ArrayList<Message> al = new ArrayList<Message>(messages.values());
		ArrayList<Message> rl = new ArrayList<Message>();
		for(Message m:al){
			if(m.getAuthor().startsWith(author)){
				rl.add(m);
			}

		}
		return rl;
	}
	

}
