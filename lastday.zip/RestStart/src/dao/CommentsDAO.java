package dao;

import java.util.Map;

import domain.Comment;

public interface CommentsDAO {

	public Map<Integer, Comment> getAllComments(int messageId);

	public Comment addComment(int messageId, Comment comment);

}
