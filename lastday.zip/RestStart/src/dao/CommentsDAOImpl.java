package dao;

import java.util.Map;

import domain.Comment;
import domain.Message;

public class CommentsDAOImpl implements CommentsDAO {

	@Override
	public Map<Integer,Comment> getAllComments(int messageId) {
		
		Message msg = MessageDAOImpl.messages.get(messageId);
		return msg.getComments();
	}

	@Override
	public Comment addComment(int messageId, Comment comment) {

		Map<Integer,Comment> comments = MessageDAOImpl.messages.get(messageId).getComments();
		comment.setId(comments.size()+1);
		comments.put(comment.getId(), comment);
		
		return comment;
	}

}
