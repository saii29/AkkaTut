package service;

import java.util.Map;

import dao.CommentsDAO;
import dao.CommentsDAOImpl;
import domain.Comment;
import service.CommentsService;

public class CommentsServiceImpl implements CommentsService {
private CommentsDAO dao = new CommentsDAOImpl();

	@Override
	public Map<Integer,Comment> getAllComments(int messageId) {
		// TODO Auto-generated method stub
		return dao.getAllComments(messageId);
	}

	@Override
	public Comment addComment(int messageId, Comment comment) {
		// TODO Auto-generated method stub
		return dao.addComment(messageId, comment);
	}

}
