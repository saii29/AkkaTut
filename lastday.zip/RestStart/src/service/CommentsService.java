package service;

import java.util.Map;

import domain.Comment;

public interface CommentsService {
	Map<Integer,Comment> getAllComments(int messageId);
	Comment addComment(int messageId, Comment comment);
	

}
