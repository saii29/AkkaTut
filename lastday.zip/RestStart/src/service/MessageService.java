package service;

import java.util.List;

import domain.Message;

public interface MessageService {
	
	public List<Message> getMessage();
	public Message addMessage(Message message);
	public Message updateMessage(int id, Message message);
	public void deleteMessage(int id);
	public Message getMessage(int id);
	public List<Message> getMessages(String author);
	

}
