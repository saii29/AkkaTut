package service;

import java.util.List;

import dao.MessageDAO;
import dao.MessageDAOImpl;
import domain.Message;

public class MessageServiceImpl implements MessageService {
MessageDAO dao = new MessageDAOImpl();
	@Override
	public List<Message> getMessage() {
		// TODO Auto-generated method stub
		return dao.getMessage();
	}

	@Override
	public Message addMessage(Message message) {
		// TODO Auto-generated method stub
		return dao.addMessage(message);
	}

	@Override
	public Message updateMessage(int id, Message message) {
		// TODO Auto-generated method stub
		return dao.updateMessage(id, message);
	}

	@Override
	public void deleteMessage(int id) {
		// TODO Auto-generated method stub
		dao.deleteMessage(id);
	}

	@Override
	public Message getMessage(int id) {
		// TODO Auto-generated method stub
		return dao.getMessage(id);
	}

	@Override
	public List<Message> getMessages(String author) {
		// TODO Auto-generated method stub
		return dao.getMessages(author);
	}

}
