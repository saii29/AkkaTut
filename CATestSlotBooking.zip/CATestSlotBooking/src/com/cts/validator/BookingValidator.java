package com.cts.validator;

import java.util.Date;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cts.vo.BookingSlotVO;

/**
 * 
 * @BookingValidator class with validate method to validate all the input
 *                   attributes
 *
 */
public class BookingValidator implements Validator {

	@SuppressWarnings("rawtypes")
	@Override
	public boolean supports(Class clazz) {
		return BookingSlotVO.class.isAssignableFrom(clazz);
	}

	/**
	 * validate method with Object and Errors as args
	 * 
	 */
	@Override
	public void validate(Object target, Errors errors) {

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "employeeId",
				"required.employeeId", "Employee Id is required!");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "employeeName",
				"required.employeeName", "Employee Name is required!");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email",
				"required.email", "Field name is required.");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phone",
				"required.phone", "Field name is required.");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "accountName",
				"required.accountName", "Field name is required!");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "assessmentName",
				"required.assessmentName", "Field name  is required!");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "level",
				"required.level", "Field name is required!");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "slot",
				"required.slot", "Field name is required.");

		// *************************************************************************************************************
		BookingSlotVO detailsVO = (BookingSlotVO) target;

		employeeIDValidation(errors, detailsVO);

		employeeNameValidation(errors, detailsVO);

		emailValidation(errors, detailsVO);

		phoneNumberValidation(errors, detailsVO);

		dateOfAssessmentValidation(errors, detailsVO);
	}

	/**
	 * @param errors
	 * @param detailsVO
	 */
	private void dateOfAssessmentValidation(Errors errors,
			BookingSlotVO detailsVO) {
		if (detailsVO.getDateOfAssessment() == null) {
			errors.rejectValue("dateOfAssessment", "required.dateOfAssessment");
		}

		if (detailsVO.getDateOfAssessment() != null) {

			Date date = (Date) detailsVO.getDateOfAssessment();
			Date date1 = new Date();

			if (date.before(date1)) {
				errors.rejectValue("dateOfAssessment",
						"before.dateOfAssessment");
			}
		}
	}

	/**
	 * @param errors
	 * @param detailsVO
	 */
	private void phoneNumberValidation(Errors errors, BookingSlotVO detailsVO) {
		if (!(detailsVO.getPhone().equals("") || detailsVO.getPhone().equals(
				null))) {
			if (!(detailsVO.getPhone().matches("\\d{10}"))) {
				errors.rejectValue("phone", "phone.format");
			}
		}
	}

	/**
	 * @param errors
	 * @param detailsVO
	 */
	private void emailValidation(Errors errors, BookingSlotVO detailsVO) {
		if (!(detailsVO.getEmail().equals("") || detailsVO.getEmail().equals(
				null))) {
			if (!(detailsVO.getEmail()
					.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$"))) {
				errors.rejectValue("email", "invalid.email");
			}
		}
	}

	/**
	 * @param errors
	 * @param detailsVO
	 */
	private void employeeNameValidation(Errors errors, BookingSlotVO detailsVO) {
		if (!(detailsVO.getEmployeeName().equals("") || detailsVO
				.getEmployeeName().equals(null))) {
			if (!(detailsVO.getEmployeeName().matches("^[a-zA-Z\\s]{2,30}$"))) {
				errors.rejectValue("employeeName", "invalid.employeeName");
			}
		}
	}

	/**
	 * @param errors
	 * @param detailsVO
	 */
	private void employeeIDValidation(Errors errors, BookingSlotVO detailsVO) {
		if (!(detailsVO.getEmployeeId().equals("") || detailsVO.getEmployeeId()
				.equals(null))) {
			if (!(detailsVO.getEmployeeId().matches("\\d{6}"))) {
				errors.rejectValue("employeeId", "invalid.employeeId");
			}
		}
	}
}