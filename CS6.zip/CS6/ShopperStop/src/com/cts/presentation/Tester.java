/**
 * This file contains Tester class
 */
package com.cts.presentation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.bo.DetailsVO;
import com.cts.bo.PurchaseOrderVO;
import com.cts.exceptions.InvalidCustomerNameException;
import com.cts.exceptions.InvalidEmailException;
import com.cts.exceptions.InvalidProductCodeException;
import com.cts.exceptions.InvalidQuantityException;
import com.cts.exceptions.NoRecordsException;
import com.cts.manager.ShoppingManager;


/**
 * <h3>Description :</h3>This is the tester class of the application which
 * displays the menu and accepts data and populates the transfer object and
 * sends it to the Manager class.
 * 
 * @author Academy Java Solutions, Bangalore, Cognizant Technology Solutions
 */
public class Tester {
	 
	private static ShoppingManager manager;
	private static PurchaseOrderVO orderVO;
	private static ApplicationContext context;
		

	public void purchaseProduct() {
			
	
		
			  try {
				Integer poNo= manager.purchaseProduct(orderVO);
				  			  
				  if(poNo!=0)
					{
						System.out.println("Purchase successfully with Purchase OrderNo "+poNo); 
					}
					else{
						System.out.println("Sorry .. Registration was Unsuccessfull..");
					}
			} catch (InvalidCustomerNameException e) {
				e.getMessage();
			} catch (InvalidEmailException e) {
				e.getMessage();
			} catch (InvalidProductCodeException e) {
				e.getMessage();
			} catch (InvalidQuantityException e) {
				e.getMessage();
			}catch(Exception e){
				e.printStackTrace();
			}
			
		

	}

	public void viewSalesReport() {
		String report=context.getMessage("report", 
				null, Locale.US);
		String enter=context.getMessage("enter", 
				null, Locale.US);
		
		System.out.println("\n\n\n\n"); 
		System.out.println("  ****   "+report+"   ****"); 
		System.out.println("  -----------------------------------------"); 
		
		System.out.print("  "+enter+"   :"); 
		Integer productCode=Integer.parseInt(acceptString());
	
		System.out.println();

		 List<DetailsVO> list;
		try {
			list = manager.viewSalesReport(productCode);
			System.out.println("\n\nPurchaseOrderNo	 CustomerName	ProductName		Quantity		Amount		dateOfPurchase	noOfStock	category"); 
			 System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			for(DetailsVO vo:list ){
				
				String dateOfPurchase= new DateUtility().getStringFromDate(vo.getDateOfPurchase());
				 
				System.out.println("\t"+vo.getPurchaseOrderNo()+"\t\t\t  "+vo.getCustomerName()+"\t\t\t"+vo.getProductName()+"\t\t "+vo.getQuantity()+"\t\t\t"+vo.getAmount()+"\t\t "+dateOfPurchase+"\t\t  "+vo.getNoOfStock()+"\t\t "+vo.getCategory());
			 }
			
		} catch (NoRecordsException e) {
		
			//e.getMessage();
			System.out.println("List is empty");
			//e.printStackTrace();
		} catch (Exception e) {
			
			
		
			e.printStackTrace();
		}
		
				
	}
	
	public void displayEnglish(){
		
			
		String title = context.getMessage("title", 
				null, Locale.US);
		String service1 = context.getMessage("service1", 
				null, Locale.US);
		String service2 = context.getMessage("service2", 
				null, Locale.US);
		String service3 = context.getMessage("service3", 
				null, Locale.US);
		String ch=context.getMessage("choice", 
				null, Locale.US);
		
		while (true) {
					
			System.out.println();
			System.out.println("**********************************"); 
			System.out.println(title);				 
			System.out.println("***********************************");
			System.out.println(service1); 
			System.out.println(service2);		
			System.out.println(service3); 

			System.out.print("\n"+ch+" : "); 

			// accepting the choice
			String choice = acceptString();
			int option = 0;
			try {
				// parsing the accepted option into integer
				option = Integer.parseInt(choice);
				// choosing the right module
				switch (option) {
				case 1:
					purchaseProduct();
					break;
				case 2:
					viewSalesReport();
					break;
				case 3:
				//	System.out.println(exiting+" !!!");
					System.exit(0);
				default:
					//System.out.println(vailidInput);
					break;
				}
			} catch (Exception exception) {
				System.out
						.println("\n\nThis is an error message from Starter Class - \nDetails of exception : "
								+ exception);
			}
		}
		
	}
	
public void displayFrench(){
		
	
	
	String title = context.getMessage("title", 
			null, Locale.FRENCH);
	String service1 = context.getMessage("service1", 
			null, Locale.FRENCH);
	String service2 = context.getMessage("service2", 
			null, Locale.FRENCH);
	String service3 = context.getMessage("service3", 
			null, Locale.FRENCH);
	String urChoice=context.getMessage("choice", 
			null, Locale.FRENCH);
	String exiting=context.getMessage("exiting", 
			null, Locale.FRENCH);
	String validInput=context.getMessage("vailidInput", 
			null, Locale.FRENCH);
	
	while (true) {

		System.out.println();
		System.out.println("**********************************"); 
		System.out.println(title);				 
		System.out.println("***********************************");
		System.out.println(service1); 
		System.out.println(service2);		
		System.out.println(service3); 

		System.out.print("\n"+urChoice+" : "); 

		// accepting the choice
		String choice = acceptString();
		int option = 0;
		try {
			// parsing the accepted option into integer
			option = Integer.parseInt(choice);
			// choosing the right module
			switch (option) {
			case 1:
				purchaseProduct();
				break;
			case 2:
				viewSalesReport();
				break;
			case 3:
				System.out.println(exiting);
				System.exit(0);
			default:
				System.out.println(validInput);
				break;
			}
		} catch (Exception exception) {
			System.out
					.println("\n\nThis is an error message from Starter Class - \nDetails of exception : "
							+ exception);
		}
	}
	
		
	}

	public static void main(String args[]) throws Exception {

		context = new ClassPathXmlApplicationContext(
				"spring1.xml");

		manager = (ShoppingManager) context.getBean("manager");
		orderVO=(PurchaseOrderVO)context.getBean("orderVO");
		
		
		while (true) {
		System.out.println();
		System.out.println("**********************************"); 
		System.out.println("  Pls select the language ");				 
		System.out.println("***********************************");
		System.out.println("    1. English"); 
		System.out.println("    2. French");		
		System.out.println("    3. Exit"); 
		
		
		System.out.print("\n Enter the choice : "); 

		// accepting the choice
		String choice = acceptString();
		int option = 0;
		try {
			// parsing the accepted option into integer
			option = Integer.parseInt(choice);
			// choosing the right module
			switch (option) {
			case 1:
				new Tester().displayEnglish();
				break;
			case 2:
				new Tester().displayFrench();
				break;
			case 3:
				System.out.println("Exiting the application!!!");
				System.exit(0);
			default:
				System.out.println("Please enter a Valid input i.e 1/2/3");
				break;
			}
		} catch (Exception exception) {
			System.out
					.println("\n\nThis is an error message from Starter Class - \nDetails of exception : "
							+ exception);
		}
		}
		
	}

	public static String acceptString() {
		// the return variable initialization
		String stringData = null;
		BufferedReader input = null;
		try {
			// chaining the streams
			input = new BufferedReader(new InputStreamReader(System.in));

			// reading data from the reader
			stringData = input.readLine();
		} catch (IOException ioException) {
			System.out.println("Error in accepting data.");
		} finally {
			input = null;
		}
		return stringData;
	}

}
