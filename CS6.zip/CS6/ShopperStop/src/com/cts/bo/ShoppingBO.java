package com.cts.bo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.dao.Product;
import com.cts.dao.ShoppingDao;
import com.cts.exceptions.InvalidCustomerNameException;
import com.cts.exceptions.InvalidEmailException;
import com.cts.exceptions.InvalidProductCodeException;
import com.cts.exceptions.InvalidQuantityException;
import com.cts.exceptions.NoRecordsException;

@Component("shoppingBO")
public class ShoppingBO {
	
	private ShoppingDao shoppingDao;
	
	public ShoppingDao getShoppingDao() {
		return shoppingDao;
	}

	@Autowired
	public void setShoppingDao(ShoppingDao shoppingDao) {
		this.shoppingDao = shoppingDao;
	}

	public Integer purchaseProduct(PurchaseOrderVO orderVO)
			throws InvalidCustomerNameException, InvalidEmailException, InvalidProductCodeException, InvalidQuantityException {

		String Name = orderVO.getCustomerName();
		for (int i = 0; i < Name.length(); i++) {
			if (!((Name.charAt(i) >= 65 && Name.charAt(i) <= 90)
					|| (Name.charAt(i) >= 97 && Name.charAt(i) <= 123) || (Name
						.charAt(i) == 32))) {
				throw new InvalidCustomerNameException();
			}
		}

		String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		if (!(orderVO.getEmailId().matches(EMAIL_REGEX))) {
			throw new InvalidEmailException();
		}

		Product product = shoppingDao.getProductDetails(orderVO.getProductCode());
		if (product == null) {
			throw new InvalidProductCodeException();
		}
		
		if(orderVO.getQuantity()>shoppingDao.getProductDetails(orderVO.getProductCode()).getNoOfStock()){
			throw new InvalidQuantityException();
		}

		return shoppingDao.purchaseProduct(orderVO);

	}

	public List<DetailsVO> viewSalesReport(Integer productCode) throws NoRecordsException {
		List<DetailsVO> list= shoppingDao.viewSalesReport(productCode);
		if(list.size()==0){
			throw new NoRecordsException();
		}
		return list;

	}

}
