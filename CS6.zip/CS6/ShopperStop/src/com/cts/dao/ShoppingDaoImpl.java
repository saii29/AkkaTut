package com.cts.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bo.DetailsVO;
import com.cts.bo.PurchaseOrderVO;

@Repository("shoppingDao")
public class ShoppingDaoImpl extends JdbcDaoSupport implements ShoppingDao{

	@Override
	@Transactional
	public Product getProductDetails(Integer productCode) {
		Product product=null;
		try{
		String sql = "SELECT * FROM Product  WHERE productCode = ?";

		product = (Product) getJdbcTemplate().queryForObject(sql,	new Object[] { productCode }, new ProductRowMapper());
		}catch (final EmptyResultDataAccessException e) {
			return null;
		}
		return product;
	}

	@Override
	@Transactional
	public Integer purchaseProduct(PurchaseOrderVO orderVO) {
		
		double totalAmount= getProductDetails(orderVO.getProductCode()).getProductPrice()*orderVO.getQuantity();
		
		String sql = "INSERT INTO PurchaseOrder "
				+ "(customerName,emailId,productCode,quantity,amount,dateOfPurchase ) VALUES (?, ?,?,?,?,?)";
		
		getJdbcTemplate().update(sql,
				new Object[] { orderVO.getCustomerName(), orderVO.getEmailId(),orderVO.getProductCode(),orderVO.getQuantity(),totalAmount,new Date()});
	
		Product product = getProductDetails(orderVO.getProductCode());
		
		String sql1 ="UPDATE Product  SET  noOfStock=?  where productCode=?" ;
		
		int stock = product.getNoOfStock()-orderVO.getQuantity();
		
		getJdbcTemplate().update(sql1, new Object[] {stock , product.getProductCode()});
		
		
		String sql2 = "SELECT * FROM PurchaseOrder ";

		List<PurchaseOrder> registrationList = getJdbcTemplate().query(sql2,	new PurchaseOrderRowMapper());

		 int size=registrationList. size();
		return registrationList.get(size-1).getPurchaseOrderNo();
		
	}

	@Override
	@Transactional(readOnly=true)
	public List<DetailsVO> viewSalesReport(Integer productCode) {
		String sql = "select *  from PurchaseOrder where productCode=? ";
		List<PurchaseOrder> purchaseOrders = getJdbcTemplate().query(sql,
				new Object[] { productCode },	new PurchaseOrderRowMapper());
		List<DetailsVO> detailsVOList = new ArrayList<DetailsVO>();

		//System.out.println("registrations size " + registrations.size());

		Iterator<PurchaseOrder> iterator = purchaseOrders.iterator();
		while (iterator.hasNext()) {
			PurchaseOrder po = (PurchaseOrder) iterator.next();

			DetailsVO vo = new DetailsVO();
			vo.setPurchaseOrderNo(po.getPurchaseOrderNo());
			vo.setCustomerName(po.getCustomerName());
			vo.setQuantity(po.getQuantity());
			vo.setDateOfPurchase(po.getDateOfPurchase());
			vo.setAmount(po.getAmount());
						
			Product product  = getProductDetails(po.getProductCode());
			if (product != null) {
				
				vo.setProductName(product.getProductName());
				vo.setNoOfStock(product.getNoOfStock());
				vo.setCategory(product.getCategory());
			}

			detailsVOList.add(vo);

		}
		//System.out.println("detailsTOList" + detailsVOList.size());
		return detailsVOList;
	}

}
