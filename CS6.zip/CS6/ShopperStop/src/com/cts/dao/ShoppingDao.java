package com.cts.dao;

import java.util.List;

import com.cts.bo.DetailsVO;
import com.cts.bo.PurchaseOrderVO;

public interface ShoppingDao {
	
	public Product getProductDetails(Integer productCode); 

	public Integer purchaseProduct(PurchaseOrderVO orderVO) ; 
	
	public List<DetailsVO> viewSalesReport(Integer productCode);	

}
