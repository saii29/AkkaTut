package com.cts.dao;

public class Product {
	
	private Integer productCode;
	private String productName;
	private Double productPrice;
	private Integer noOfStock;
	private String category;
	public Integer getProductCode() {
		return productCode;
	}
	public void setProductCode(Integer productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	public Integer getNoOfStock() {
		return noOfStock;
	}
	public void setNoOfStock(Integer noOfStock) {
		this.noOfStock = noOfStock;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
		
	
	
	

}
