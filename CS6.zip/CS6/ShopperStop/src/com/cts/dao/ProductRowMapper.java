package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ProductRowMapper implements RowMapper<Product>{
	
	public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		Product product = new Product();
		product.setProductCode(rs.getInt("productCode"));
		product.setProductName(rs.getString("productName"));
		product.setProductPrice(rs.getDouble("productPrice"));
		product.setNoOfStock(rs.getInt("noOfStock"));
		product.setCategory(rs.getString("category"));
		
		return product;
	}

}
