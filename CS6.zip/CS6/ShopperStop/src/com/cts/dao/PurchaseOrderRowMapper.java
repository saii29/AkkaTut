package com.cts.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class PurchaseOrderRowMapper implements RowMapper<PurchaseOrder>{
	
	public PurchaseOrder mapRow(ResultSet rs, int rowNum) throws SQLException {
		PurchaseOrder order = new PurchaseOrder();
		
		order.setPurchaseOrderNo(rs.getInt("purchaseOrderNo"));
		order.setCustomerName(rs.getString("customerName"));
		order.setEmailId(rs.getString("emailId"));
		order.setProductCode(rs.getInt("productCode"));
		order.setQuantity(rs.getInt("quantity"));
		order.setAmount(rs.getDouble("Amount"));
		order.setDateOfPurchase(rs.getDate("dateOfPurchase"));
		
		
		
		
		return order;
	}

}
