package com.cts.facade;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.bo.DetailsVO;
import com.cts.bo.PurchaseOrderVO;
import com.cts.bo.ShoppingBO;
import com.cts.exceptions.InvalidCustomerNameException;
import com.cts.exceptions.InvalidEmailException;
import com.cts.exceptions.InvalidProductCodeException;
import com.cts.exceptions.InvalidQuantityException;
import com.cts.exceptions.NoRecordsException;

@Component("shoppingFacade")
public class ShoppingFacade {

	private ShoppingBO shoppingBO;

	public ShoppingFacade() {

	}

	@Autowired
	public ShoppingFacade(ShoppingBO shoppingBO) {
		this.shoppingBO = shoppingBO;
	}

	public Integer purchaseProduct(PurchaseOrderVO orderVO)
			throws InvalidCustomerNameException, InvalidEmailException,
			InvalidProductCodeException, InvalidQuantityException {

		return shoppingBO.purchaseProduct(orderVO);

	}

	public List<DetailsVO> viewSalesReport(Integer productCode)
			throws NoRecordsException {

		return shoppingBO.viewSalesReport(productCode);
	}

}
