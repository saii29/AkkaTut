package com.cts.exceptions;

@SuppressWarnings("serial")
public class InvalidCustomerNameException extends Exception {
	
	public InvalidCustomerNameException(){
		super("Customer Name should consists of only alphabets and space");
	}

}
