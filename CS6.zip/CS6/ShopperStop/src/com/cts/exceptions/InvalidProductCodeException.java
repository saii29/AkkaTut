package com.cts.exceptions;

@SuppressWarnings("serial")
public class InvalidProductCodeException extends Exception {
	
	public InvalidProductCodeException(){
		super("Product Code entered should be valid");
	}

}
