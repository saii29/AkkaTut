package com.cts.exceptions;

@SuppressWarnings("serial")
public class InvalidQuantityException extends Exception {

	public InvalidQuantityException(){
		super("Invalid quantity entered ");
	}
}
