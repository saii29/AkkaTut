package com.cts.exceptions;

@SuppressWarnings("serial")
public class NoRecordsException extends Exception {
public NoRecordsException(){
	super("No records are avaible");
}
}
