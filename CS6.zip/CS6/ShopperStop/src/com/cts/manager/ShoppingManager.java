package com.cts.manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.bo.DetailsVO;
import com.cts.bo.PurchaseOrderVO;
import com.cts.exceptions.InvalidCustomerNameException;
import com.cts.exceptions.InvalidEmailException;
import com.cts.exceptions.InvalidProductCodeException;
import com.cts.exceptions.InvalidQuantityException;
import com.cts.exceptions.NoRecordsException;
import com.cts.facade.ShoppingFacade;

@Component("manager")
public class ShoppingManager {

	private ShoppingFacade facade;

	public ShoppingFacade getFacade() {
		return facade;
	}

	@Autowired
	public void setFacade(ShoppingFacade facade) {
		this.facade = facade;
	}

	public Integer purchaseProduct(PurchaseOrderVO orderVO)
			throws InvalidCustomerNameException, InvalidEmailException,
			InvalidProductCodeException, InvalidQuantityException {

		return facade.purchaseProduct(orderVO);

	}

	public List<DetailsVO> viewSalesReport(Integer productCode)
			throws NoRecordsException {

		return facade.viewSalesReport(productCode);
	}

}
