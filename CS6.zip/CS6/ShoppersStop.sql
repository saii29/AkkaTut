DROP SCHEMA springjdbc;

CREATE SCHEMA springjdbc;

use springjdbc;

DROP table if exists Product;
DROP table if exists PurchaseOrder;



CREATE TABLE Product(
productCode INT NOT NULL AUTO_INCREMENT  PRIMARY KEY,
productName VARCHAR(50) NOT NULL,
productPrice DOUBLE NOT NULL,
noOfStock INT NOT NULL,
category VARCHAR(50) NOT NULL);


CREATE TABLE PurchaseOrder(
purchaseOrderNo INTEGER(5) NOT NULL AUTO_INCREMENT PRIMARY KEY,
customerName VARCHAR(30) NOT NULL,
emailId VARCHAR(30) NOT NULL,
productCode INTEGER(6) NOT NULL,
quantity INTEGER(3) NOT NULL,
Amount DOUBLE NOT NULL,
dateOfPurchase DATE NOT NULL,
FOREIGN KEY (productCode ) REFERENCES Product(productCode));


INSERT INTO Product VALUES(1,'Apple iPhone',20650,1000,'mobile');
INSERT INTO Product VALUES(2,'Seagate Expansion',7050,1000,'external hard disk');
INSERT INTO Product VALUES(3,'Dell Inspiron',32050,1000,'laptop');
INSERT INTO Product VALUES(4,'Google Nexus7 Tablet',27050,1000,'tablet');



INSERT INTO PurchaseOrder VALUES( 1,'Rohit','rht@gmail.com',1,1,20650,'2012-07-04');



select * from Product;

select * from PurchaseOrder;

